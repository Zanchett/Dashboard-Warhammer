import LoginScreen from '../components/login-screen'

export default function Home() {
  return (
    <main>
      <LoginScreen />
    </main>
  )
}

