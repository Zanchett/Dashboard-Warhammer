import RegisterScreen from '../../components/register-screen'

export default function RegisterPage() {
  return (
    <main>
      <RegisterScreen />
    </main>
  )
}

